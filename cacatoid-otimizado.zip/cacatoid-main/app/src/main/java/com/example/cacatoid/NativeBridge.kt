package com.example.cacatoid

/**
 * JNI bridge to the native Bitcoin puzzle searcher.
 *
 * All cryptography and key iteration runs in C++ (see app/src/main/cpp). The
 * native side spawns [threadCount] worker threads plus a monitor thread that
 * invokes [SearchListener.onStats] roughly every 500 ms. A match triggers
 * [SearchListener.onFound] immediately from the worker that found it.
 */
object NativeBridge {

    init {
        System.loadLibrary("cacatoid")
    }

    interface SearchListener {
        /** @param currentKeyHex 64-char hex of a key currently under test
         *  @param keysPerSec    aggregate throughput across all threads
         *  @param totalChecked  total keys checked since the search started */
        fun onStats(currentKeyHex: String, keysPerSec: Long, totalChecked: Long)

        /** Fired once when a target address is matched. */
        fun onFound(privKeyHex: String, wif: String, address: String, puzzle: Int)
    }

    /**
     * Starts (or restarts) the search for the given puzzle.
     * @param threadCount number of worker threads; 0 = use all CPU cores.
     */
    external fun nativeStart(puzzle: Int, threadCount: Int, listener: SearchListener)

    /** Stops the search and joins all native threads. Safe to call when idle. */
    external fun nativeStop()

    /** Returns the number of hardware threads (CPU cores) on this device. */
    external fun nativeGetCoreCount(): Int
}
