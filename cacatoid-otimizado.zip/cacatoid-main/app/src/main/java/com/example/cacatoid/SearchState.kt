package com.example.cacatoid

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

/**
 * Process-wide search state, decoupled from any Activity or ViewModel.
 * [SearchService] owns the running search and writes here; the UI observes.
 */
object SearchState {

    data class Stats(
        val currentKeyHex: String = "",
        val keysPerSec: Long = 0,
        val totalChecked: Long = 0,
    )

    data class Found(
        val puzzle: Int,
        val privKeyHex: String,
        val wif: String,
        val address: String,
    )

    private val _running = MutableLiveData(false)
    val running: LiveData<Boolean> = _running

    private val _stats = MutableLiveData(Stats())
    val stats: LiveData<Stats> = _stats

    private val _found = MutableLiveData<Found?>(null)
    val found: LiveData<Found?> = _found

    /** Last puzzle the user chose; retained so the dropdown restores correctly. */
    var selectedPuzzle: Int = 71

    /**
     * Thread count chosen by the user. 0 = use all cores (auto).
     * Clamped to [1..coreCount] in the UI; stored here so it survives
     * Activity recreation.
     */
    var selectedThreadCount: Int = 0

    fun setRunning(value: Boolean) = _running.postValue(value)
    fun setStats(value: Stats)     = _stats.postValue(value)
    fun setFound(value: Found?)    = _found.postValue(value)

    fun reset() {
        _stats.postValue(Stats())
        _found.postValue(null)
    }
}
