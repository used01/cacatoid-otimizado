package com.example.cacatoid

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData

class SearchViewModel(app: Application) : AndroidViewModel(app) {

    val running: LiveData<Boolean> = SearchState.running
    val stats: LiveData<SearchState.Stats> = SearchState.stats
    val found: LiveData<SearchState.Found?> = SearchState.found

    var selectedPuzzle: Int
        get() = SearchState.selectedPuzzle
        set(value) { SearchState.selectedPuzzle = value }

    var selectedThreadCount: Int
        get() = SearchState.selectedThreadCount
        set(value) { SearchState.selectedThreadCount = value }

    /** Total hardware threads on this device (read once, cached). */
    val coreCount: Int by lazy { NativeBridge.nativeGetCoreCount() }

    fun start() {
        if (running.value == true) return
        val intent = Intent(getApplication(), SearchService::class.java)
            .putExtra(SearchService.EXTRA_PUZZLE, selectedPuzzle)
            .putExtra(SearchService.EXTRA_THREAD_COUNT, selectedThreadCount)
        ContextCompat.startForegroundService(getApplication(), intent)
    }

    fun stop() {
        if (running.value == false) return
        val intent = Intent(getApplication(), SearchService::class.java)
            .setAction(SearchService.ACTION_STOP)
        getApplication<Application>().startService(intent)
    }
}
