#include "secp256k1_utils.h"
#include "sha256.h"
#include "ripemd160.h"

#include <secp256k1.h>
#include <mutex>
#include <cstring>

// Static assert: PubKey is layout-compatible with secp256k1_pubkey so we can
// cast between them directly and skip two memcpy() calls per key checked.
static_assert(sizeof(ec::PubKey) == sizeof(secp256k1_pubkey),
              "PubKey must be layout-compatible with secp256k1_pubkey");

namespace ec {

namespace {
secp256k1_context* g_ctx = nullptr;
std::once_flag g_once;

// Big-endian scalar 1, used as the +G tweak every iteration.
const uint8_t ONE[32] = {
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,1 };
} // namespace

void init() {
    std::call_once(g_once, [] {
        g_ctx = secp256k1_context_create(SECP256K1_CONTEXT_NONE);
    });
}

// Cast PubKey* directly to secp256k1_pubkey* — same 64-byte layout, zero copy.
bool pubkey_create(const uint8_t seckey[32], PubKey& out) {
    return secp256k1_ec_pubkey_create(
        g_ctx,
        reinterpret_cast<secp256k1_pubkey*>(&out),
        seckey
    ) != 0;
}

// pubkey += 1*G — the hot-path advance between consecutive keys.
// No copies: operates on PubKey in place via reinterpret_cast.
bool pubkey_increment(PubKey& pub) {
    return secp256k1_ec_pubkey_tweak_add(
        g_ctx,
        reinterpret_cast<secp256k1_pubkey*>(&pub),
        ONE
    ) != 0;
}

void serialize_compressed(const PubKey& pub, uint8_t out[33]) {
    size_t len = 33;
    secp256k1_ec_pubkey_serialize(
        g_ctx,
        out,
        &len,
        reinterpret_cast<const secp256k1_pubkey*>(&pub),
        SECP256K1_EC_COMPRESSED
    );
}

// HASH160 = RIPEMD160(SHA256(compressed_pubkey)).
// Serializes into a stack buffer, then hashes in one pass — no heap allocation.
void hash160_compressed(const PubKey& pub, uint8_t out[20]) {
    uint8_t ser[33];
    serialize_compressed(pub, ser);
    uint8_t sha[32];
    sha256(ser, 33, sha);
    ripemd160(sha, 32, out);
}

} // namespace ec
