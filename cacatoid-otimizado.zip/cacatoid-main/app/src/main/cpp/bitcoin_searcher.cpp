#include <jni.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cstring>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include "secp256k1_utils.h"
#include "base58.h"

#define LOG_TAG "BtcSearcher"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using u128 = unsigned __int128;
using Clock = std::chrono::steady_clock;

namespace {

// ---- Target addresses (compressed P2PKH) keyed by puzzle number ----
struct Target { int puzzle; const char* addr; };
constexpr Target TARGETS[] = {
    { 20, "1HsMJxNiV7TLxmoF6uJNkydxPFDog4NQum" },
    { 71, "1PWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU" },
    { 72, "1JTK7s9YVYywfm5XUH7RNhHJH1LshCaRFR" },
    { 73, "12VVRNPi4SJqUTsp6FmqDqY5sGosDtysn4" },
};

const char* target_address(int puzzle) {
    for (const auto& t : TARGETS) if (t.puzzle == puzzle) return t.addr;
    return nullptr;
}

// Larger batch = fewer atomic ops per key, less cache-line contention.
// 4096 is a sweet spot: enough to amortize overhead, small enough that
// g_running/g_found checks stay responsive.
constexpr int BATCH = 4096;

// ---- JNI / threading state ----
JavaVM*   g_vm = nullptr;
std::mutex g_mutex;
std::vector<std::thread> g_workers;
std::thread g_monitor;

std::atomic<bool>     g_running{false};
std::atomic<bool>     g_found{false};
std::atomic<uint64_t> g_total{0};

// Current key reported to the UI: stored as two 64-bit halves of a u128.
// Written by workers, read by the monitor — relaxed ordering is fine here
// because this is display data only.
std::atomic<uint64_t> g_cur_lo{0};
std::atomic<uint64_t> g_cur_hi{0};

jobject   g_listener  = nullptr;
jmethodID g_on_stats  = nullptr;
jmethodID g_on_found  = nullptr;

// Found result — set once under the CAS in g_found.
u128 g_found_key    = 0;
int  g_active_puzzle = 0;

// ---- helpers ----

void u128_to_key(u128 v, uint8_t key[32]) {
    memset(key, 0, 32);
    for (int i = 0; i < 16; i++) key[31 - i] = uint8_t(v >> (i * 8));
}

// Write exactly len*2 hex chars into dst (must have room). No allocation.
void to_hex_buf(const uint8_t* src, size_t len, char* dst) {
    static constexpr char H[] = "0123456789abcdef";
    for (size_t i = 0; i < len; i++) {
        dst[i * 2]     = H[src[i] >> 4];
        dst[i * 2 + 1] = H[src[i] & 0xf];
    }
}

std::string key_hex(u128 v) {
    uint8_t key[32];
    u128_to_key(v, key);
    char buf[64];
    to_hex_buf(key, 32, buf);
    return std::string(buf, 64);
}

// WIF for a compressed key: base58check(0x80 || privkey || 0x01).
std::string to_wif(const uint8_t key[32]) {
    uint8_t payload[34];
    payload[0] = 0x80;
    memcpy(payload + 1, key, 32);
    payload[33] = 0x01;
    return base58check_encode(payload, 34);
}

// P2PKH address: base58check(0x00 || hash160).
std::string to_address(const uint8_t hash160[20]) {
    uint8_t payload[21];
    payload[0] = 0x00;
    memcpy(payload + 1, hash160, 20);
    return base58check_encode(payload, 21);
}

JNIEnv* attach_env(bool& attached) {
    JNIEnv* env = nullptr;
    attached = false;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
        attached = true;
    }
    return env;
}

void report_found(u128 key_value, int puzzle) {
    uint8_t key[32];
    u128_to_key(key_value, key);

    ec::PubKey pub;
    ec::pubkey_create(key, pub);
    uint8_t hash[20];
    ec::hash160_compressed(pub, hash);

    char hex_buf[64];
    to_hex_buf(key, 32, hex_buf);
    std::string priv_hex(hex_buf, 64);
    std::string wif  = to_wif(key);
    std::string addr = to_address(hash);

    LOGI("MATCH puzzle %d priv=%s addr=%s", puzzle, priv_hex.c_str(), addr.c_str());

    bool attached = false;
    JNIEnv* env = attach_env(attached);
    if (env && g_listener) {
        jstring jp = env->NewStringUTF(priv_hex.c_str());
        jstring jw = env->NewStringUTF(wif.c_str());
        jstring ja = env->NewStringUTF(addr.c_str());
        env->CallVoidMethod(g_listener, g_on_found, jp, jw, ja, (jint)puzzle);
        env->DeleteLocalRef(jp);
        env->DeleteLocalRef(jw);
        env->DeleteLocalRef(ja);
    }
    if (attached) g_vm->DetachCurrentThread();
}

// ---------------------------------------------------------------------------
// Worker thread
// ---------------------------------------------------------------------------
// Each worker owns a sub-range [sub_start, sub_end], picks a random starting
// offset within it, and increments the public key by +G each step (one EC
// point addition instead of a full scalar multiplication per key).
//
// Optimisations vs. original:
//   • BATCH increased to 4096 — 4× fewer atomic ops per key checked.
//   • Loop compares directly against one 20-byte target (no spurious 3-way
//     loop — the caller fills all three slots identically so we just use [0]).
//   • g_cur_lo/hi updated only once per batch, not inside the inner loop.
//   • local counter flushed to g_total only once per batch.
// ---------------------------------------------------------------------------
void worker_run(u128 sub_start, u128 sub_end,
                const uint8_t target[20], int puzzle) {
    ec::init();
    const u128 len = sub_end - sub_start + 1;

    // Random starting offset within the sub-range.
    std::random_device rd;
    std::mt19937_64 rng(((uint64_t)rd() << 32) ^ rd());
    u128 offset = ((u128)rng() << 64 | rng()) % len;
    u128 cur = sub_start + offset;

    uint8_t seckey[32];
    u128_to_key(cur, seckey);
    ec::PubKey pub;
    if (!ec::pubkey_create(seckey, pub)) return;

    uint8_t hash[20];
    u128 done = 0;

    while (done < len) {
        if (g_found.load(std::memory_order_relaxed) ||
            !g_running.load(std::memory_order_relaxed))
            break;

        const u128 remaining = len - done;
        const int batch = (remaining < (u128)BATCH) ? (int)remaining : BATCH;

        for (int b = 0; b < batch; b++) {
            ec::hash160_compressed(pub, hash);

            // Compare 4 bytes first (fast reject ~99.9999% of keys),
            // then the full 20 bytes only on the rare partial match.
            if (__builtin_expect(
                    (*(const uint32_t*)hash == *(const uint32_t*)target) &&
                    (memcmp(hash, target, 20) == 0), 0))
            {
                g_found_key = cur;
                bool expected = false;
                if (g_found.compare_exchange_strong(expected, true)) {
                    report_found(cur, puzzle);
                }
                g_total.fetch_add((uint64_t)(done + b + 1), std::memory_order_relaxed);
                return;
            }

            // Advance to next key.
            if (cur == sub_end) {
                // Wrap around to the start of the sub-range.
                cur = sub_start;
                u128_to_key(cur, seckey);
                if (!ec::pubkey_create(seckey, pub)) return;
            } else {
                cur++;
                // pubkey_increment is a fast EC point addition (+G).
                // Falls back to full scalar multiply only on negligible failures.
                if (!ec::pubkey_increment(pub)) {
                    u128_to_key(cur, seckey);
                    if (!ec::pubkey_create(seckey, pub)) return;
                }
            }
        }

        done += batch;
        // Flush counter and publish current key once per batch.
        g_total.fetch_add((uint64_t)batch, std::memory_order_relaxed);
        g_cur_lo.store((uint64_t)cur,        std::memory_order_relaxed);
        g_cur_hi.store((uint64_t)(cur >> 64), std::memory_order_relaxed);
    }
}

// ---------------------------------------------------------------------------
// Monitor thread — fires onStats ~2× per second, no hot-path involvement.
// ---------------------------------------------------------------------------
void monitor_run() {
    bool attached = false;
    JNIEnv* env = attach_env(attached);

    uint64_t last_total = 0;
    auto last_time = Clock::now();

    while (g_running.load(std::memory_order_relaxed) &&
           !g_found.load(std::memory_order_relaxed))
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        auto now = Clock::now();
        uint64_t total = g_total.load(std::memory_order_relaxed);
        double secs = std::chrono::duration<double>(now - last_time).count();
        uint64_t kps = (secs > 0) ? (uint64_t)((total - last_total) / secs) : 0;
        last_total = total;
        last_time  = now;

        u128 cur = ((u128)g_cur_hi.load(std::memory_order_relaxed) << 64) |
                   g_cur_lo.load(std::memory_order_relaxed);

        if (env && g_listener) {
            std::string hex = key_hex(cur);
            jstring jhex = env->NewStringUTF(hex.c_str());
            env->CallVoidMethod(g_listener, g_on_stats, jhex, (jlong)kps, (jlong)total);
            env->DeleteLocalRef(jhex);
        }
    }
    if (attached) g_vm->DetachCurrentThread();
}

void cleanup_locked(JNIEnv* env) {
    g_running.store(false);
    for (auto& t : g_workers) if (t.joinable()) t.join();
    g_workers.clear();
    if (g_monitor.joinable()) g_monitor.join();
    if (g_listener) {
        env->DeleteGlobalRef(g_listener);
        g_listener = nullptr;
    }
}

} // namespace

// ---------------------------------------------------------------------------
// JNI entry points
// ---------------------------------------------------------------------------

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

// nativeStart(puzzle, threadCount, listener)
// threadCount == 0  →  use hardware_concurrency (all cores).
extern "C" JNIEXPORT void JNICALL
Java_com_example_cacatoid_NativeBridge_nativeStart(JNIEnv* env, jobject /*thiz*/,
                                                   jint puzzle,
                                                   jint thread_count,
                                                   jobject listener) {
    std::lock_guard<std::mutex> lock(g_mutex);
    cleanup_locked(env);

    const char* addr = target_address(puzzle);
    if (!addr) {
        LOGE("unsupported puzzle %d", (int)puzzle);
        return;
    }

    g_listener = env->NewGlobalRef(listener);
    jclass cls = env->GetObjectClass(listener);
    g_on_stats = env->GetMethodID(cls, "onStats", "(Ljava/lang/String;JJ)V");
    g_on_found = env->GetMethodID(cls, "onFound", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V");
    if (!g_on_stats || !g_on_found) {
        LOGE("could not resolve listener methods");
        env->DeleteGlobalRef(g_listener);
        g_listener = nullptr;
        return;
    }

    // Decode target address once at startup — never touched in the hot path.
    ec::init();
    static uint8_t s_target[20];
    std::vector<uint8_t> decoded = base58check_decode(addr);
    if (decoded.size() != 21) {
        LOGE("failed to decode target address for puzzle %d", (int)puzzle);
        env->DeleteGlobalRef(g_listener);
        g_listener = nullptr;
        return;
    }
    memcpy(s_target, decoded.data() + 1, 20);

    // Key range: puzzle n covers [2^(n-1), 2^n - 1].
    u128 lo = (u128)1 << (puzzle - 1);
    u128 hi = (((u128)1 << puzzle) - 1);

    g_found.store(false);
    g_total.store(0);
    g_cur_lo.store((uint64_t)lo);
    g_cur_hi.store((uint64_t)(lo >> 64));
    g_active_puzzle = puzzle;
    g_running.store(true);

    // Determine thread count: caller supplies it; 0 means "all cores".
    unsigned hw = std::thread::hardware_concurrency();
    if (hw == 0) hw = 4;
    unsigned nthreads = (thread_count > 0 && (unsigned)thread_count <= hw)
                        ? (unsigned)thread_count
                        : hw;

    u128 span = hi - lo + 1;
    u128 per  = span / nthreads;
    if (per == 0) { per = span; nthreads = 1; }

    LOGI("start puzzle %d with %u/%u threads", (int)puzzle, nthreads, hw);

    for (unsigned i = 0; i < nthreads; i++) {
        u128 s = lo + (u128)i * per;
        u128 e = (i == nthreads - 1) ? hi : (lo + (u128)(i + 1) * per - 1);
        g_workers.emplace_back([s, e, puzzle]() {
            worker_run(s, e, s_target, puzzle);
        });
    }
    g_monitor = std::thread(monitor_run);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_cacatoid_NativeBridge_nativeStop(JNIEnv* env, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    cleanup_locked(env);
    LOGI("stopped; total checked=%llu", (unsigned long long)g_total.load());
}

// Returns the number of hardware threads available on this device.
// Used by the UI to populate the thread-count slider max value.
extern "C" JNIEXPORT jint JNICALL
Java_com_example_cacatoid_NativeBridge_nativeGetCoreCount(JNIEnv*, jobject) {
    unsigned hw = std::thread::hardware_concurrency();
    return (jint)(hw > 0 ? hw : 4);
}
